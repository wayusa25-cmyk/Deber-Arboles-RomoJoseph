# Deber Arboles

Aplicación Java para representar el catálogo de la Biblioteca FISEI mediante un árbol general n-ario y un ABB por estante.

## Ejecución

Desde la carpeta del proyecto:

```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java src).FullName
java -cp out app.Main
java -cp out app.PruebasBiblioteca
```

Las clases están organizadas en `enums`, `modelo`, `negocio` y `app`. Las operaciones estructurales se implementan con recursividad y no se usan colecciones ordenadas ni métodos de ordenamiento.
